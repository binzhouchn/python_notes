XGBoost Python Package
======================
This page contains links to all the python related documents on python package.
To install the package package, checkout [Build and Installation Instruction](../build.md).

Contents
--------
* [Python Overview Tutorial](python_intro.md)
* [Learning to use XGBoost by Example](../../demo)
* [Python API Reference](python_api.rst)
